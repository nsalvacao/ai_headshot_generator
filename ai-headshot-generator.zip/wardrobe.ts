/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

// No default items are needed for the headshot generator.
