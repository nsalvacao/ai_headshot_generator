/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

// This component is not used in the current application flow.
const CurrentOutfitPanel = () => null;
export default CurrentOutfitPanel;